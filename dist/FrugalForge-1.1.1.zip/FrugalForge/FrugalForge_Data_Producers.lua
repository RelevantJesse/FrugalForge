﻿FrugalForgeProducers = {
  {
    outputItemId = 2840,
    outputQty = 1,
    reagents = {
      { itemId = 2770, qty = 1 },
    },
  },
  {
    outputItemId = 3576,
    outputQty = 1,
    reagents = {
      { itemId = 2771, qty = 1 },
    },
  },
  {
    outputItemId = 2841,
    outputQty = 2,
    reagents = {
      { itemId = 2840, qty = 1 },
      { itemId = 3576, qty = 1 },
    },
  },
  {
    outputItemId = 2842,
    outputQty = 1,
    reagents = {
      { itemId = 2775, qty = 1 },
    },
  },
  {
    outputItemId = 3577,
    outputQty = 1,
    reagents = {
      { itemId = 2776, qty = 1 },
    },
  },
  {
    outputItemId = 6037,
    outputQty = 1,
    reagents = {
      { itemId = 7911, qty = 1 },
    },
  },
  {
    outputItemId = 3575,
    outputQty = 1,
    reagents = {
      { itemId = 2772, qty = 1 },
    },
  },
  {
    outputItemId = 3860,
    outputQty = 1,
    reagents = {
      { itemId = 3858, qty = 1 },
    },
  },
  {
    outputItemId = 12359,
    outputQty = 1,
    reagents = {
      { itemId = 10620, qty = 1 },
    },
  },
}
